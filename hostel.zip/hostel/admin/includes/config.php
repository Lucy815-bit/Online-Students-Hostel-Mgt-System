<?php
$dbuser="root";
$dbpass="k@r1bun1";
$host="localhost";
$db="hostel";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>